package org.utility;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	
public static WebDriver driver;
	
	public static WebDriver launchBrowser(String browsername) {
		if(browsername.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browsername.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		else if(browsername.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		return driver;
	}
	public static WebDriver launchBrowser1(String browsername) {
		switch(browsername) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case"firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case"edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		}
		return driver;
	}
	
	public static WebDriver chromeBrowser() {
		WebDriverManager.chromedriver().setup();
		return driver= new ChromeDriver();
	}
	public static WebDriver firefoxBrowser() {
		WebDriverManager.firefoxdriver().setup();
		return driver = new FirefoxDriver();
	}
	public static WebDriver edgeBrowser() {
		WebDriverManager.edgedriver().setup();
		return driver = new EdgeDriver();
	}
	public static void urlLaunch(String Url) {
		driver.get(Url);
	}
	public static void maximize() {
		driver.manage().window().maximize();
	}
	public static void implicitWait(long secs) {
		driver.manage().timeouts().implicitlyWait(secs, TimeUnit.SECONDS);
	}
	public void sendKeys(WebElement e, String value) {
		e.sendKeys(value);
	}
	
	public static void click(WebElement e) {
		e.click();
	}
	public static void clear(WebElement e) {
		e.clear();
	}
	public static String getUrl() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;
	}
	public static String getTitle() {
		String title = driver.getTitle();
		return title;
	}
	public static String getPageSource() {
		String pageSource = driver.getPageSource();
		return pageSource;
	}
	public static String getText(WebElement e) {
		String text = e.getText();
		return text;
	}
	public static String getAtttribute(WebElement e) {
		String att = e.getAttribute("value");
		return att;
	}
	public static File  getScreenshot(WebElement e) {
		File screenshotAs = e.getScreenshotAs(OutputType.FILE );
		return screenshotAs;	
	}
	public static String getTagname(WebElement e) {
		String tagName = e.getTagName();
		return tagName;
	}
	public static boolean display(WebElement e) {
		boolean displayed = e.isDisplayed();
		return displayed;
	}
	public static boolean selected(WebElement e) {
		boolean selected = e.isSelected();
		return selected;
	}
	public static boolean enabled(WebElement e) {
		boolean enabled = e.isEnabled();
		return enabled;
	}
	public static void moveToElement(WebElement target) {
		Actions a = new Actions(driver);
		a.moveToElement(target).perform();
	}
	public static void dragAndDrop(WebElement to, WebElement From) {
		Actions a1 = new Actions(driver);
		a1.dragAndDrop(From, to).perform();
	}
	public static void clickAndHold(WebElement target) {
		Actions a2 = new Actions(driver);
		a2.clickAndHold().perform();
	}
	public static void rightClick() {
		Actions a3 = new Actions(driver);
		a3.contextClick().perform();
	}
	public static void doubleClick() {
		Actions a4 = new Actions(driver);
		a4.doubleClick().perform();
	}
	public static void selectByIndex(WebElement e, int i) {
		Select s = new Select(e);
		s.selectByIndex(i);
	}
	public static void selectByValue(WebElement e, String string) {
		Select s1 = new Select(e);
		s1.selectByValue(string);
	}
	public static void selectByVisibletext(WebElement e, String string) {
		Select s2 = new Select(e);
		s2.selectByVisibleText(string);
	}
	public static void getFirstSelectedOptions(WebElement e) {
		Select s3 = new Select(e);
		s3.getFirstSelectedOption();
	}
	public static  List<WebElement> getOptions(WebElement e) {
		Select s4 = new Select(e);
		List<WebElement> options = s4.getOptions();
		return options;
	}
	public static void close() {
		driver.close();
	}
public static void quit() {
	driver.quit();
}
	
	public static void refresh() {
		driver.navigate().refresh();
	}
	public static void back() {
		driver.navigate().back();
	}


}
