package org.recenttransaction;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utility.BaseClass;

public class RecentTrans extends BaseClass {
	
	public void RecentTrans() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[text()='View Recent Transactions']")
	private WebElement transaction;
	
	public WebElement getTransaction() {
		return transaction;
	}

}
