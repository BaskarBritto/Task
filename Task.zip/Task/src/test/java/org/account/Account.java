package org.account;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utility.BaseClass;

public class Account extends BaseClass {
	
	public void Account() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[text()='View Account Summary']")
	private WebElement account;
	
	public WebElement getAccount() {
		return account;
	}
	
	@FindBy(id = "listAccounts")
	private WebElement list;
	
	public WebElement getList() {
		return list;
	}
	
	@FindBy(id = "btnGetAccount")
	private WebElement go;
	
	public WebElement getGo() {
		return go;
	}
	
	@FindBy(id = "MenuHyperLink3")
	private WebElement transferFunds;
	
	public WebElement getTransfer() {
		return transferFunds;
		
	}
	
	@FindBy(id = "toAccount")
	private WebElement toAccount;
	
	public WebElement getToAccount() {
		return toAccount;
		
	}
	@FindBy(id = "transferAmount")
	private WebElement transferAmountText;
	
	public WebElement gettransferAmount() {
		return transferAmountText;
		
	}	
	
	@FindBy(id = "transfer")
	private WebElement transferBtn;
	
	public WebElement gettransferBtn() {
		return transferBtn;
		
	}	

}
