package org.signin;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utility.BaseClass;

public class SignIn extends BaseClass {
		
		public void Signin() {
			PageFactory.initElements(driver, this);
		}
		@CacheLookup
		@FindBy(xpath="//font[text()='Sign In']")
		private WebElement signIn;
		
		public WebElement getSignIn() {
			return signIn;
		}
		@FindBy(id ="uid")
		private WebElement userName;
		
		@FindBy(id="passw")
		private WebElement userPass;
		
		@FindBy(name="btnSubmit")
		private WebElement submit;

		public WebElement getUserName() {
			return userName;
		}

		public WebElement getUserPass() {
			return userPass;
		}

		public WebElement getSubmit() {
			return submit;
		}
		
		
		
}
