package org.appdata;

import java.util.List;

import org.account.Account;
import org.contact.ContactUs;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.recenttransaction.RecentTrans;
import org.signin.SignIn;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.utility.BaseClass;

public class data extends BaseClass{
	
public static WebDriver driver;
	
	@BeforeClass
	private void beforeClass() {
		System.out.println("Before class");
	}
	@BeforeMethod
	private void beforeMethod() {
		System.out.println("Before method");
	}
	@AfterMethod
	private void afterMethod() {
		System.out.println("After method");
	}
	@AfterClass
	private void afterClass() {
		System.out.println("After class");
	}
	@Test(priority = 0)
	public void credentials() throws InterruptedException {
		launchBrowser("chrome");
		maximize();
		implicitWait(10);
		urlLaunch("http://testfire.net/index.jsp");
		SignIn s = new SignIn();
		Thread.sleep(3000);
		//sign in 
		click(s.getSignIn());
		
		//Invalid credentials
		Thread.sleep(3000);
		sendKeys(s.getUserName(), "demo_user");
		sendKeys(s.getUserPass(), "demo_password");
		click(s.getSubmit());
		Thread.sleep(3000);
		String atUser = getAtttribute(s.getUserName());
		Assert.assertEquals("verify username", "demo_user", atUser);
		String atPass = getAtttribute(s.getUserPass());
		Assert.assertEquals("verify userpassword", "demo_password", atPass);
		
		//valid credentials
		Thread.sleep(3000);
		sendKeys(s.getUserName(), "admin");
		sendKeys(s.getUserPass(), "admin");
		click(s.getSubmit());
		
	}
	
	@Test(priority = 1)
	public void accountSummary() throws InterruptedException {
		
		//view account summary
		implicitWait(10);
		Account a = new Account();
		click(a.getAccount());
		Thread.sleep(3000);
		a.selectByValue(a.getList(), "800001");
		click(a.getGo());
		
		//View available balance
		System.out.println("Available Balance");
		List<WebElement> tables = driver.findElements(By.tagName("table"));
		WebElement table1 = tables.get(0);
		
		List<WebElement> datas = table1.findElements(By.tagName("td"));
		for (int i =0; i<datas.size(); i++) {
			WebElement data = datas.get(i);
			String text2 = data.getText();
			System.out.println(text2);
		}
		Assert.assertEquals("verify availabe balance", "available balance");
		Thread.sleep(3000);
		click(a.getTransfer());
		a.selectByValue(a.getToAccount(), "800001");
		sendKeys(a.gettransferAmount(), "9876");
		click(a.gettransferBtn());
		
		//validate the amount
		String amount = new String ();
		boolean amt = amount.contains("9876.0 was successfully transferred");
		Assert.assertTrue(amt);
		
	}
	
	@Test(priority = 2)
	public void recentTrans() {
		RecentTrans r = new RecentTrans();
		click(r.getTransaction());
		
		System.out.println("validate first 2 rows");
		List<WebElement> tables = driver.findElements(By.tagName("table"));
		WebElement table1 = tables.get(0);
		
		List<WebElement> row = table1.findElements(By.tagName("tr"));
		for(int i=0; i<row.size(); i++) {
			WebElement tRows = row.get(i);
			System.out.println(tRows.getText());
		}
		

		for(int i=0; i<row.size();i++) {
			WebElement data2 = row.get(i);
		System.out.println(data2.getText());
		}
		
	}
	
	@Test(priority = 3)
	public void contact() {
		ContactUs c = new ContactUs();
		click(c.getContactUs());
		click(c.getOnlineForm());
		clear(c.getYourName());
		sendKeys(c.getYourName(), "Britto");
		sendKeys(c.getYouraddr(), "britto@gmail.com");
		sendKeys(c.getSubject(), "Task Completed");
		sendKeys(c.getcomments(), "I have completed my task");
		click(c.getsubmit());	
		
		
	}

}
