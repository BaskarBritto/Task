package org.contact;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utility.BaseClass;

public class ContactUs extends BaseClass {
	
	public void ContactUs() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[text()='Contact Us']")
	private WebElement contact;
	
	public WebElement getContactUs() {
		return contact;
	}
	
	@FindBy(xpath = "//a[text()='online form']")
	private WebElement form;
	
	public WebElement getOnlineForm() {
		return form;
	}
	
	@FindBy(name = "name")
	private WebElement yourName;
	
	public WebElement getYourName() {
		return yourName;
	}
	
	@FindBy(name = "email_addr")
	private WebElement youraddr;
	
	public WebElement getYouraddr() {
		return youraddr;
	}
	@FindBy(name = "subject")
	private WebElement subject;
	
	public WebElement getSubject() {
		return subject;
	}
	
	@FindBy(name = "comments")
	private WebElement comments;
	
	public WebElement getcomments() {
		return comments;
	}
	
	@FindBy(name = "submit")
	private WebElement submit;
	
	public WebElement getsubmit() {
		return submit;
	}
	
	

}
